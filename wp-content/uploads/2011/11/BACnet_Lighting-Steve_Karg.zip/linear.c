/**************************************************************************
*
* Copyright (C) 2011 Steve Karg <skarg@users.sourceforge.net>
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*********************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include "linear.h"

/*************************************************************************
* Description: Linearly Interpolate the values
* Returns: y2 - an intermediate y value
* Notes: a method of constructing new data points within the range of
* a discrete set of known data points.
**************************************************************************/
float linear_interpolate(
    float x1,
    float x2,
    float x3,
    float y1,
    float y3)
{
    float y2;

    if (y3 > y1) {
        y2 = y1 + (((x2 - x1) * (y3 - y1)) / (x3 - x1));
    } else {
        y2 = y1 - (((x2 - x1) * (y1 - y3)) / (x3 - x1));
    }

    return y2;
}

/*************************************************************************
* Description: Linearly Interpolate the values
* Returns: y2 - an intermediate y value
* Notes: a method of constructing new data points within the range of
* a discrete set of known data points.
**************************************************************************/
long linear_interpolate_int(
    long x1,
    long x2,
    long x3,
    long y1,
    long y3)
{
    float y2;

    y2 = linear_interpolate(x1, x2, x3, y1, y3);
    /* round away from zero */
    if (y2 > 0.0) {
        y2 += 0.5;
    } else if (y2 < 0.0) {
        y2 -= 0.5;
    }

    return (long)y2;
}
