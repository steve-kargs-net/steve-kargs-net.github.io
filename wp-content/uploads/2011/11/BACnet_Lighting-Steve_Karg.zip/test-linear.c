/**************************************************************************
*
* Copyright (C) 2011 Steve Karg <skarg@users.sourceforge.net>
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*********************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "ctest.h"
#include "linear.h"

static void testLinearInterpolateInt(
    Test * pTest)
{
    uint16_t x2 = 0;
    uint16_t y1 = 0;
    uint16_t y2 = 0;
    uint16_t y3 = 0;
    uint16_t x2_test = 0;

    y2 = linear_interpolate_int(1, 1, 65535, 1, 100);
    ct_test(pTest, y2 == 1);
    y2 = linear_interpolate_int(1, 1, 65535, 100, 1);
    ct_test(pTest, y2 == 100);

    y2 = linear_interpolate_int(1, 65535, 65535, 1, 100);
    ct_test(pTest, y2 == 100);
    y2 = linear_interpolate_int(1, 65535, 65535, 100, 1);
    ct_test(pTest, y2 == 1);

    y2 = linear_interpolate_int(1, (65535/2), 65535, 1, 100);
    ct_test(pTest, y2 == 50);

    y2 = linear_interpolate_int(1, (65535/4), 65535, 1, 100);
    ct_test(pTest, y2 == 26);

    y2 = linear_interpolate_int(1, ((65535*3)/4), 65535, 1, 100);
    ct_test(pTest, y2 == 75);

    y2 = linear_interpolate_int(1, 1, 100, 1, 65535);
    ct_test(pTest, y2 == 1);

    y2 = linear_interpolate_int(1, 100, 100, 1, 65535);
    ct_test(pTest, y2 == 65535);

    y2 = linear_interpolate_int(1, 100/2, 100, 1, 65535);
    ct_test(pTest, y2 == 32437);

    /* scaling from percent to steps and back */
    for (x2 = 1; x2 <= 100; x2++) {
        y2 = linear_interpolate_int(1, x2, 100, 1, 65535);
        x2_test = linear_interpolate_int(1, y2, 65535, 1, 100);
        ct_test(pTest, x2 == x2_test);
    }

    /* test for low-trim, high-trim and scaling from percent to steps */
    for (x2 = 1; x2 <= 100; x2++) {
        y1 = linear_interpolate_int(1, 20, 100, 1, 65535);
        y3 = linear_interpolate_int(1, 80, 100, 1, 65535);
        y2 = linear_interpolate_int(1, x2, 100, y1, y3);
        x2_test = linear_interpolate_int(y1, y2, y3, 1, 100);
        ct_test(pTest, x2 == x2_test);
        if (x2 != x2_test) {
            printf("x2=%hu x2_test=%hu\n", x2, x2_test);
        }
    }

    y2 = linear_interpolate_int(1, 1, 65535, 20, 80);
    ct_test(pTest, y2 == 20);
    y2 = linear_interpolate_int(1, 1, 65535, 80, 20);
    ct_test(pTest, y2 == 80);
    y2 = linear_interpolate_int(1, 65535, 65535, 20, 80);
    ct_test(pTest, y2 == 80);
    y2 = linear_interpolate_int(1, 65535, 65535, 80, 20);
    ct_test(pTest, y2 == 20);
}

#ifdef TEST_LINEAR
int main(
    void)
{
    Test *pTest;
    bool rc;

    pTest = ct_create("Linear Interpolation", NULL);

    /* individual tests */
    rc = ct_addTestFunction(pTest, testLinearInterpolateInt);
    assert(rc);

    ct_setStream(pTest, stdout);
    ct_run(pTest);
    (void) ct_report(pTest);

    ct_destroy(pTest);

    return 0;
}
#endif
